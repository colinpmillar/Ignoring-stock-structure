#' Extracts the catch and survey data, makes useful summaries
#' and places them in an environment
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{extractData} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
extractData <- function(stock, index) {
  
  # check inputs
  stopifnot(inherits(stock, "FLStock"))
  stopifnot(inherits(index, "FLIndex"))

  # TODO investigate plus group issue
  # can't use plus groups at the moment
  plus.group  <- identical( unname(range(stock)["plusgroup"]), unname(range(stock)["max"]) )
  if (plus.group)
  {
    stock <- stock[paste(1:(range(stock, "max") - 1)),]
    #index <- index[paste(1:min(range(stock, "max") - 1, range(index, "max"))),]
    index <- index[1:min(range(stock, "max"), range(index, "max")),]
  }
  
  # remove class structure and drop extra dimensions
  catch <- drop( catch.n(stock) @ .Data )
  index <- drop(   index(index) @ .Data )

  # as we are working on log scales zeros should be replaced
  # with an appropriate value
  catch <- replaceZeros(catch)
  index <- replaceZeros(index)


  # collect useful data summaries
  i.ages      <- as.numeric(rownames(index))
  i.years     <- as.numeric(colnames(index))
  c.ages      <- as.numeric(rownames(catch))
  c.years     <- as.numeric(colnames(catch))
  ages        <- min(i.ages, c.ages) : max(i.ages, c.ages)
  years       <- min(i.years, c.years) : max(i.years, c.years)
  n.ages      <- length(ages)
  n.years     <- length(years)
  ages.in.c   <- ages %in% c.ages
  years.in.c  <- years %in% c.years
  ages.in.i   <- ages %in% i.ages
  years.in.i  <- years %in% i.years


  # set up data data frame
  data <- expand.grid(age = 1:n.ages, year = 1:n.years)
  data $ survey.age <- ifelse(data $ age %in% i.ages, data $ age, max(i.ages))
  data $ cohort <- data $ year - data $ age + 1
  
  # this assumes the stock object covers the range of interest 
  data $ mortality <- c( drop(        m(stock) @ .Data ))
  data $ maturity  <- c( drop(      mat(stock) @ .Data ))
  data $ weight    <- c( drop( stock.wt(stock) @ .Data ))

  # add observations using NA for no observation
  index.mask <- ages.in.i %*% t(years.in.i)
  index.mask[index.mask == 0] <- NA
  index.mask[!is.na(index.mask)] <- c(index)
  
  catch.mask <- ages.in.c %*% t(years.in.c)
  catch.mask[catch.mask==0] <- NA
  catch.mask[!is.na(catch.mask)] <- c(catch)
  
  data $ catch  <- log(c(catch.mask))
  data $ survey <- log(c(index.mask))
  
  n.catch  <- sum(as.numeric(!is.na(catch.mask)))
  n.survey <- sum(as.numeric(!is.na(index.mask)))
  n.y      <- n.catch + n.survey
  n.data   <- nrow(data)

  # matrices that map catch and survey to total data	
  Mc <- Diagonal(x = c(as.numeric(!is.na(catch.mask))))	
  Mc <- Mc[rowSums(Mc) == 1,]
  Ms <- Diagonal(x = c(as.numeric(!is.na(index.mask))))	
  Ms <- Ms[rowSums(Ms) == 1,]
  
  # the cumulative summed Z matrix in n equation 
  Xcf <- matrix(0, n.data, n.data)
  # add a previous year if age is greater than 1
  for (i in 2:n.ages)
  {
	  ndrop <- (i-1) * (n.ages + 1)
	  insum <- c( rep( rep(c(1,0),c(n.ages-i+1, i-1)), n.data / n.ages - i), rep(1,n.ages-i+1)) 
	  diag(Xcf[-(1:ndrop), ndrop:1 - n.data - 1]) <- insum  
  }
  Xcf <- Matrix(Xcf)
  
  y <- c(data $ catch [!is.na(data $ catch )], 
		 data $ survey[!is.na(data $ survey)])
  
  # the offset matrix - might not use this
  Xoffset <- rBind( cBind(Mc, Mc),
		            cBind(Ms, Matrix(0, n.survey, n.data)))
  
  # return the local environment
  environment()
}
