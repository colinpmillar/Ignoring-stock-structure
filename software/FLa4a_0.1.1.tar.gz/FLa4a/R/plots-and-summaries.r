#' Displays a summary of a fitted model
#'
#' Currently only the coefficients and the log likelihood is displayed.
#'
#' @param obj a fitted a4a model
#' @return NULL
#' @note \code{summarya4aLinear} is dispached by \code{summary}
#' @references \url{https://github.com/colinpmillar/FLa4a}
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
summarya4aFit <- function(obj) {
  env <- attr(obj, "env")
  print(env $ log.likelihood)
	
  invisible(NULL)
}


#' Plots a fitted model
#'
#' Currently only the coefficients and the log likelihood is displayed.
#'
#' @param obj a fitted a4a model
#' @return NULL
#' @note \code{summarya4aLinear} is dispached by \code{summary}
#' @references \url{https://github.com/colinpmillar/FLa4a}
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
plota4aFit <- function(obj) {
	env <- attr(obj, "env")

	dev.new()
	print( xyplot(q ~ survey.age, env $ data, type = "p", main = "survey selectivity") )
	
	dev.new()
	print( xyplot(r ~ cohort, subset(env $ data, cohort >= 1), type = "p", main = "recruitment") )

	dev.new()
	print( xyplot(f ~ age | year, env $ data, type = "l", main = "F at age") )
	
	invisible(NULL)
}
