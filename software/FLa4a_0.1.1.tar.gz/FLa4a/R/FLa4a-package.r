#' A simple and robust statistical catch at age model
#'
#' \tabular{ll}{
#' Package: \tab FLa4a \cr
#' Type: \tab Package \cr
#' Version: \tab 0.1 \cr
#' Date: \tab 2012-08-17 \cr
#' License: \tab GPL (>= 2) \cr
#' LazyLoad: \tab yes \cr
#' }
#'
#' @name FLa4a-package
#' @aliases FLa4a
#' @docType package
#' @import Matrix
#' @import FLCore
#' @import FLAssess
#' @import FLXSA
#' @title Tests pseudoprimality by Fermat's little theorem
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @author Ernesto Jardim \email{ernesto.jardim@@jrc.ec.europa.eu}
#' @references none
#' @keywords package
#' @seealso \code{\link{paste}}
#' @examples
#' data(ple4)
#' data(ple4.index)
#'
#' yr1 <- 1980
#' yr2 <- 2008
#' stock <- ple4[paste(1:9),paste(yr1:yr2)]
#' index <- ple4.index[,paste(max(1985, yr1):yr2)]
#' 
#' # the model
#' f.model <- ~ factor(age) + factor(year)
#' q.model <- ~ bs(survey.age, 3)
#' r.model <- ~ 1
#' 
#' fit <- a4aFit(stock, index, f.model = f.model, q.model = q.model, r.model = r.model,
#' 		      fit.variances = FALSE, survey.weights = 1,  
#' 		      control = list(trace = 10, hessian = FALSE))
#' 
#' summarya4aFit(fit)
#' plota4aFit(fit)
NULL
