#' Replaces zeros with smallest observed non zero catch/index in that age class age
#'
#' Fermat's little theorem states that if \eqn{n} is a prime
#' number and \eqn{a} is any positive integer less than \eqn{n},
#' then \eqn{a} raised to the \eqn{n}th power is congruent to
#' \eqn{a\ modulo\ n}{a modulo n}.
#'
#' @param obj a numeric array containing the catch or survey indices
#' @return obj with zeros replaced
#' @note \code{replaceZeros} is intended to be used internally
#' @references 
#'   Something
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
replaceZeros <- function(obj) {
  for (i in 1:nrow(obj))
    obj[i,] <- replace(obj[i,], obj[i,] == 0, sort(unique(obj[i,]))[2])

  obj
}


#' Extracts the catch and survey data, makes useful summaries
#' and places them in an environment
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{extractData} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
timer <- 
		function(msg = NULL, reset = FALSE, report = TRUE, last = FALSE)
{
	if (reset || !exists("._.timer", .GlobalEnv)) assign("._.timer", unname(proc.time()[1]), envir = .GlobalEnv)    
	assign("._.timer", c(unname(proc.time()[1]), ._.timer), envir = .GlobalEnv)
	if (report)
	{ 
		fmt <- "%7.2fs"
		if (!last) 
			cat(sprintf(fmt, ._.timer[1] - ._.timer[2]))
		else 
			cat(sprintf(fmt, diff(range(._.timer))))
	}
	if (!is.null(msg)) cat(msg)
	flush.console()
}
environment(timer) <- .GlobalEnv

# TODO generateDataFromStock <- function(stock, q.model, q.par, cv)
#function(stock) # to generate catch and survey observations
#{
#	ages <- 1:min(9, range(stock)["max"])
#	range(stock)[c("minfbar","maxfbar")] <- c(2, min(5, max(ages)))
#	
#	stock <- setPlusGroup(stock, max(ages))
#	stock <- stock[, paste(25:50)]
#	n <- stock.n(stock)
#	logq <- -.5 * (ages - 1) - .8 # simple decreasing catchability
#	
#	index <- FLIndex(index = n * exp(logq + rnorm(prod(dim(n)), 0, .1)))  # 10% cv
#	catch.n(stock) <- catch.n(stock) * exp(rnorm(prod(dim(n)), 0, .1)) # 10% cv
#	catch(stock) <- computeCatch( stock )
#	
#	list(stock = stock, index = index)
#})
