#' @name wklife.stk
#' @title list of FLStock objects
#' @description This data set ...
#' @docType data
#' @usage wklife.stk
#' @format ...
#' @source EJ
#' @author Ernesto Jardim
NULL

#' @name wklifeLst
#' @title list of life history parameters
#' @description This data set ...
#' @docType data
#' @usage wklifeLst
#' @format ...
#' @source EJ
#' @author Ernesto Jardim
NULL

#' @name wklife.brp
#' @title list of FLBRP objects
#' @description This data set ...
#' @docType data
#' @usage wklife.brp
#' @format ...
#' @source EJ
#' @author Ernesto Jardim
NULL
