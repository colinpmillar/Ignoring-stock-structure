#' Extracts the catch and survey data, makes useful summaries
#' and places them in an environment
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{extractData} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
a4aFit <- function(stock, index, f.model, q.model, r.model, 
		           fit.variances = FALSE, survey.weights = 1, 
				   control = list(), start = "sepVPA", debug = FALSE)
{	

  start <- match.arg(start, c("sepVPA", "XSA"))
  
  cat(  "Fitting:                ", name(stock))
  timer("\nsetting up data     ... ", reset = TRUE, report = FALSE)
	
  env <- extractData(stock, index)
	
  env $ f.model <- f.model
  env $ q.model <- q.model
  env $ r.model <- r.model
	
  env $ fit.variances <- fit.variances
  env $ survey.weights <- survey.weights
	
  eval(body(setupDesignMatrices), env)
		
  # starting values
  timer("\nintial values       ... ")
  if (start == "sepVPA") {
    init.vpa <- SepVPA(env $ stock, control = FLSepVPA.control())
  } else if (start == "XSA") {
    stop("XSA option not working yet!")
  }
  
  # need to make sure F!=0
  f <- drop(harvest(init.vpa) @ .Data)
  f[is.na(f) | f <= 0] <- min(f[f > 0], na.rm = TRUE)
  logF <- log(c(f))
  
  init.opt <- (solve(t(env $ Xf) %*% env $ Xf) %*% t(env $ Xf) %*% logF ) @ x
  
  if (!is.null(control $ start.par)) init.opt[] <- control $ start.par
  if (fit.variances) init.opt <- c(0,0,init.opt)
  
  env $ obs.var <- c(1,1)
  
  environment(getLogLikelihood) <- env
	
  timer("\nfitting             ... "); if (control $ trace > 0 & control $ do.fit) cat("\n")
  
  if (control $ do.fit) {
    opt <- nlminb(init.opt, getLogLikelihood, 
	  	          control = list(trace = control $ trace, iter.max = 1e9, eval.max = 1e9))
  } else {
	  opt <- list(par = init.opt)
  }

  env $ f.par <- opt $ par
  eval(body(getLogLikelihood), env)
  
  if (debug) {
    cat("\n input and output params\n")
    print(rbind(init.opt, opt $ par))
  }
  
  #env $ gradients <- grad(getLogLikelihood, opt $ par)
  env $ hessian <- NULL
  if (identical(control $ hessian, TRUE)) 
  {
	  timer("\ncalculating hessian ... ")
	  hessian(getLogLikelihood, opt $ par)
  }
  timer("\ncollecting output   ... ")
  
  env $ fitted.opt <- opt $ par
  env $ fitted.b <- (env $ Hb %*% env $ y.tilde) @ x
  
  env $ data $ r  <- with(env, ( cBind(Matrix(0, n.data, n.q + n.n), Xr) %*% fitted.b ) @ x)
  env $ data $ r1 <- with(env, ( cBind(Matrix(0, n.data, n.q), Xn, Matrix(0, n.data, n.r)) %*% fitted.b ) @ x)
  env $ data $ q  <- with(env, ( cBind(Xq, Matrix(0, n.data, n.n + n.r)) %*% fitted.b ) @ x)
  env $ data $ n  <- with(env, ( cBind(Matrix(0, n.data, n.q), Xn, Xr) %*% fitted.b ) @ x + data $ czfrac)

  env $ data $ fitted.catch <- with(env, ( cBind(Matrix(0, n.data, n.q), Xn, Xr) %*% fitted.b ) @ x + data $ czfrac + data $ ffrac)
  env $ data $ fitted.index <- with(env, ( cBind(Xq, Xn, Xr) %*% fitted.b ) @ x + data $ czfrac)
  
    
  ### must be a better way
  replaceQuant <- function(x, obj) 
  {
    obj @ .Data[] <- c(x)
	  obj
  }
    
  new.catch.n <- exp(env $ data $ fitted.catch)
  new.harvest <- env $ data $ f
  new.stock.n <- exp(env $ data $ n)
  
  stock.new <- env $ stock
  catch.n(stock.new) <- replaceQuant(new.catch.n, catch.n(stock.new))
  stock.n(stock.new) <- replaceQuant(new.stock.n, stock.n(stock.new))
  harvest(stock.new) <- replaceQuant(new.harvest, harvest(stock.new))
  
  catch(stock.new) <- computeCatch( stock.new )
  stock(stock.new) <- computeStock( stock.new )
  
  timer("\n--------------------------------\ntotal ellapsed          ")
  timer("\n--------------------------------\n", last = TRUE)
  
  attr(stock.new, "env") <- env
  stock.new
}

#' returns the log likelihood
#'
#' 
#' @param f.par a character string giving the model for fishing mortality
#' @param sigma.par a character string giving the model for fishing mortality
#' @param env a charnvacter string giving the model for survey catchability
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{setupDesignMatrices} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
getLogLikelihood <- function (f.par){
	
	# apply f model and get offset
	data $ f <- exp((Xf %*% f.par) @ x)
	data $ z <- data $ f + data $ mortality
	data $ czfrac <- -1 * (Xcf %*% data $ z) @ x
	data $ ffrac <- log( data $ f / data $ z * (1 - exp(-data $ z)))
	y.offset <- (Xoffset %*% c(data $ czfrac, data $ ffrac)) @ x
	y.tilde <- y - y.offset 
	
	# apply variance model and get Wy matrix
	Wy @ x <- (Xvb %*% exp(obs.var)) @ x
	# apply GMRF models and get Qb matrix
	Qb <- Qb * 0
	
	# fit depends on model type...
	if (!fit.variances)
	{	  
		y.fit <- (Hy %*% y.tilde) @ x
		
		log.likelihood <- 
				-0.5 * n.y * (log(2 * pi) + 1 - log(n.y) + log(sum((y.fit - y.tilde)^2)))
	} else {
		stop("fit.variances not developed yet")
		y.fit <- (Xb %*% solve(tXb %*% Wy %*% Xb + Qb) %*% tXb %*% Wy %*% y.tilde) @ x
		
		res <- y.fit - y.tilde
		logdetWy <- 
        log.likelihood <- 
				-0.5 * n.y * log(2 * pi) + 0.5 * logdetWy - 0.5 * sum( res * (Wy %*% res) @ x )
	}
  -2 * log.likelihood
}

