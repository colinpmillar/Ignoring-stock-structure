#' Adds the design matrices to the data environment
#'
#' 
#' @param f.model a character string giving the model for fishing mortality
#' @param q.model a character string giving the model for survey catchability
#' @param r.model a character string giving the model for recruitment 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{setupDesignMatrices} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
setupDesignMatrices <- function()
{
  
  # the model matrices
  Xf <- Matrix(model.matrix(f.model, data))   
  Xq <- Matrix(model.matrix(q.model, data))   
  Xn <- Matrix(model.matrix(~ factor(cohort) - 1, data))[,1:(n.ages-1)]
  
  # strip off first numbers
  Xr <- Matrix(model.matrix(r.model, data.frame(cohort = replace(data $ cohort, data $ cohort < 1, 1))))
  Xr[data $ cohort < 1,] <- 0
  Xr <- Xr[, apply(Xr != 0, 2, any), drop = FALSE]
  
  # number of params
  n.f <- ncol(Xf)
  n.q <- ncol(Xq)
  n.n <- ncol(Xn)
  n.r <- ncol(Xr)
  
  # the observation, beta.hat and y.hat matrices
  Xb <- rBind( cBind(Matrix(0, n.catch, n.q), Mc %*% Xn, Mc %*% Xr),
	    	   cBind(Ms %*% Xq              , Ms %*% Xn, Ms %*% Xr))
  # TODO add dimnames
  tXb <- t(Xb)
	  
  # variance design matrix
  Xv <- Matrix(model.matrix(~ 1, data))	
  Xvb <- bdiag(Mc %*% Xv, 1/survey.weights * Ms %*% Xv)
  Wy <- Diagonal(x = (Xvb %*% c(1,1)) @ x)
  
  # TODO build Q matrix ... low priority
  Qb <- Diagonal(x = rep(1, n.n + n.r + n.q))
	
  # only for use in the case of one common variance and all other variances known	
  Hb <- solve(t(Xb) %*% Wy %*% Xb) %*% t(Xb) %*% Wy
  Hy <- Xb %*% Hb

  invisible()
}



