# FLFleet - «Short one line description»
# FLFleet
# FLCore/tests/FLFleet

# Copyright 2003-2008 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, Cefas
# $Id: FLFleet.R 14 2009-01-26 15:01:42Z imosqueira $

library(FLCore)

# BUG IM_20081212_1305 validity(FLFleet)
